package cn.techtutorial.dao;

import java.sql.*;
import cn.techtutorial.model.*;

public class registerDao {
	private Connection con;

	private String query;
    private PreparedStatement pst;
    private ResultSet rs;

	public registerDao(Connection con) {
		this.con = con;
	}
	
	public User userLogin(String Name,String Address,String Email, String password) {
		User user = null;
        try {
            query = "insert into register(Name, Address, MobileNo,Email,password) values('"+Name+"','"+Address+"','"+Email+"',"+password+")";
            pst = this.con.prepareStatement(query);
            pst.setString(1, Name);
            pst.setString(2, Address);
            pst.setString(3, Email);
            pst.setString(4, password);
            rs = pst.executeQuery();
            if(rs.next()){
            	user = new User();
            	user.setId(rs.getInt("id"));
            	user.setName(rs.getString("Name"));
            	user.setAddress(rs.getString("Address"));
     
            	user.setEmail(rs.getString("Email"));
            	user.setPassword(rs.getString("password"));
            }
        } catch (SQLException e) {
            System.out.print(e.getMessage());
        }
        return user;
    }
}
